// ✅ Initialize Firebase
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  getDocs,
  doc,
  setDoc,
  getDoc,
  updateDoc
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyB2u22ywAixC_E7crQ3YzPbLJM2CSKNaTs",
  authDomain: "namma-madurai-ward.firebaseapp.com",
  projectId: "namma-madurai-ward",
};

// ✅ Prevent duplicate initialization
if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const auth = getAuth();
const db = getFirestore();

// ✅ Councilor Registration Function
async function registerCouncilor(name, email, phone, ward, zone, locality, password) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    await setDoc(doc(db, "councilors", user.uid), {
      name: name,
      email: email,
      phone: phone,
      ward_number: ward,
      zone_number: zone,
      locality: locality // ✅ Added locality field
    });

    alert("✅ Councilor registered successfully!");
    window.location.href = "Councillor_login.html"; // Redirect to login page
  } catch (error) {
    console.error("❌ Error registering councilor:", error);
    alert(error.message);
  }
}

// ✅ Councilor Login Function
async function loginCouncilor(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    const docSnap = await getDoc(doc(db, "councilors", user.uid));

    if (docSnap.exists()) {
      console.log("✅ Councilor logged in:", email);
      const locality = docSnap.data().locality;

      if (locality) {
        localStorage.setItem("councilorLocality", locality); // ✅ Store locality
        window.location.href = "councilor_dashboard.html"; // Redirect
      } else {
        alert("❌ No locality assigned. Contact support.");
      }
    } else {
      alert("❌ Not a registered councilor.");
      signOut(auth); // Log out unauthorized users
    }
  } catch (error) {
    console.error("❌ Error logging in:", error);
    alert(error.message);
  }
}

// ✅ Attach logout function globally
window.logoutAdmin = function () {
  signOut(auth)
    .then(() => {
      alert("✅ Logout Successful!");
      localStorage.removeItem("councilorLocality"); // ✅ Clear stored locality
      window.location.href = "Councillor_login.html"; // Redirect to login page
    })
    .catch((error) => {
      console.error("❌ Logout Failed:", error);
    });
};

// ✅ Function to update UI based on authentication state
function updateAuthUI(user) {
  const loginOption = document.getElementById("login-option");
  const profileOption = document.getElementById("profile-option");
  const logoutButton = document.getElementById("logout-button");

  if (user) {
    console.log("✅ Admin Logged In:", user.email);
    if (loginOption) loginOption.style.display = "none";
    if (profileOption) profileOption.style.display = "block";
    if (logoutButton) logoutButton.style.display = "block";
  } else {
    console.log("❌ Admin Not Logged In");
    if (loginOption) loginOption.style.display = "block";
    if (profileOption) profileOption.style.display = "none";
    if (logoutButton) logoutButton.style.display = "none";
  }
}

// ✅ Function to fetch complaints for the logged-in councilor
window.fetchComplaints = async function () {
  const complaintsTableBody = document.getElementById("complaintsTableBody");
  if (!complaintsTableBody) {
    console.error("❌ Complaints table not found.");
    return;
  }

  complaintsTableBody.innerHTML = ""; // ✅ Clear existing table content
  const councilorLocality = localStorage.getItem("councilorLocality"); // ✅ Get locality from login
  console.log("📍 Councilor Locality from localStorage:", councilorLocality); // Debugging log

  if (!councilorLocality) {
    console.error("❌ No locality assigned. Cannot fetch complaints.");
    alert("❌ No locality assigned. Cannot fetch complaints.");
    return;
  }

  try {
    const querySnapshot = await getDocs(collection(db, "complaints"));

    querySnapshot.forEach((docSnapshot) => {
      const complaint = docSnapshot.data();

      // ✅ Only show complaints matching the councilor's locality
      if (complaint.localityName !== councilorLocality) return;

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${complaint.complaint_id}</td>  
        <td>${complaint.name}</td>
        <td>${complaint.mobileNumber}</td>
        <td>${complaint.localityName}</td>
        <td>${complaint.wardNumber}</td>
        <td>${complaint.zoneNumber}</td>
        <td>${complaint.category}</td>
        <td>${complaint.description}</td>
        <td>
          <select class="status-dropdown" data-id="${docSnapshot.id}">
            <option value="Pending" ${complaint.status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="In Progress" ${complaint.status === "In Progress" ? "selected" : ""}>In Progress</option>
            <option value="Resolved" ${complaint.status === "Resolved" ? "selected" : ""}>Resolved</option>
          </select>
        </td>
      `;

      complaintsTableBody.appendChild(row);
    });

    // Attach event listeners to status dropdowns
    document.querySelectorAll(".status-dropdown").forEach((dropdown) => {
      dropdown.addEventListener("change", updateComplaintStatus);
    });

  } catch (error) {
    console.error("❌ Error fetching complaints:", error);
  }
};

// ✅ Function to update complaint status
async function updateComplaintStatus(event) {
  const complaintId = event.target.getAttribute("data-id");
  const newStatus = event.target.value;

  if (!complaintId) {
    console.error("❌ Invalid Complaint ID");
    return;
  }

  try {
    await updateDoc(doc(db, "complaints", complaintId), {
      status: newStatus,
    });

    alert(`✅ Complaint status updated to ${newStatus}`);
  } catch (error) {
    console.error("❌ Error updating status:", error);
  }
}

// ✅ Check Admin Authentication
onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("✅ Admin Logged In:", user.email);
    fetchComplaints(); // ✅ Ensure complaints are fetched after login
    updateAuthUI(user);
  } else {
    console.log("❌ No Admin Found. Redirecting...");
    window.location.href = "Councillor_login.html"; // Redirect to login if not logged in
  }
});

// ✅ Attach Logout Function to Button
document.addEventListener("DOMContentLoaded", () => {
  const logoutButton = document.getElementById("logout-button");
  if (logoutButton) {
    logoutButton.addEventListener("click", logoutAdmin);
  }
});
