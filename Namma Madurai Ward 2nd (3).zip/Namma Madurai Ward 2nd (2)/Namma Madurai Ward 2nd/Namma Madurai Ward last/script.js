// ✅ Function to navigate to a specific page
window.showPage = function (pageName) {
  window.location.href = pageName;
};

// ✅ Function to load content dynamically into the main section
function loadContent(url) {
  const mainContent = document.getElementById("main-content");
  if (!mainContent) return;

  fetch(url)
    .then((response) => response.text())
    .then((html) => {
      mainContent.innerHTML = html;

      if (url === "report.html") {
        initializeComplaintForm(); // Ensure complaint form is initialized after loading
      }
    })
    .catch((error) => {
      console.error("Error loading content:", error);
    });

  // ✅ Load GeoJSON for Madurai Ward Map
  fetch("madurai_wards.geojson")
    .then((response) => response.json())
    .then((data) => {
      console.log("GeoJSON Data Loaded:", data);
      if (typeof L !== "undefined") {
        L.geoJSON(data, {
          onEachFeature: function (feature, layer) {
            console.log("Ward Found:", feature.properties.name);
            layer.bindPopup(feature.properties.name);
          },
        }).addTo(map);
      } else {
        console.error("❌ Leaflet.js is not defined. Check your HTML.");
      }
    })
    .catch((error) => console.log("Error loading GeoJSON:", error));
}

// ✅ Handle Sidebar Link Click
function handleSidebarLinkClick(event) {
  event.preventDefault();
  const link = event.target.closest("a");
  if (link) {
    const url = link.getAttribute("href");
    loadContent(url);
  }
}

// ✅ Initialize Firebase only if it doesn't exist
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  setPersistence,
  browserLocalPersistence,
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  doc,
  updateDoc,
  arrayUnion,
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyB2u22ywAixC_E7crQ3YzPbLJM2CSKNaTs",

  authDomain: "namma-madurai-ward.firebaseapp.com",
  projectId: "namma-madurai-ward",
};

// ✅ Prevent Duplicate Initialization
if (!getApps().length) {
  const app = initializeApp(firebaseConfig);
  console.log("✅ Firebase Initialized Successfully!");
} else {
  console.log("⚠️ Firebase App Already Initialized.");
}

const auth = getAuth();
const db = getFirestore();

// ✅ Enable Session Persistence
setPersistence(auth, browserLocalPersistence)
  .then(() => console.log("✅ Session Persistence Enabled"))
  .catch((error) => console.error("❌ Failed to enable persistence", error));

// ✅ Function to update UI based on authentication state
function updateAuthUI(user) {
  const loginOption = document.getElementById("login-option");
  const profileOption = document.getElementById("profile-option");
  const logoutOption = document.getElementById("logout-option");

  if (user) {
    // User is logged in ✅
    console.log("🔹 Updating UI for logged-in user:", user.email);
    if (loginOption) loginOption.style.display = "none";
    if (profileOption) profileOption.style.display = "block"; // Show Profile
    if (logoutOption) logoutOption.style.display = "block";  // Show Logout
  } else {
    // User is logged out ❌
    console.log("🔹 Updating UI for logged-out state");
    if (loginOption) loginOption.style.display = "block"; // Show Login
    if (profileOption) profileOption.style.display = "none"; // Hide Profile
    if (logoutOption) logoutOption.style.display = "none";  // Hide Logout
  }
}



onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("✅ User Logged In:", user.uid);  // Logs user ID
    console.log("🔹 Email:", user.email);
    console.log("🔹 User Info:", user);

    updateAuthUI(user);
  } else {
    console.log("❌ No user found. Redirecting to login page...");
    if (!window.location.pathname.includes("login.html")) {
      window.location.href = "login.html";
    }
  }
});


// ✅ Handle Login Function
window.loginUser = () => {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  signInWithEmailAndPassword(auth, email, password)
    .then(() => {
      alert("✅ Login Successful!");
      updateAuthUI(auth.currentUser);
      window.location.href = "report.html";
    })
    .catch((error) => {
      console.error("Login Failed:", error.message);
      alert("❌ Invalid Credentials. Try Again!");
    });
};

// ✅ Handle Logout
window.logoutUser = () => {
  signOut(auth)
    .then(() => {
      alert("✅ Logout Successful!");
      updateAuthUI(null);
      window.location.href = "login.html";
    })
    .catch((error) => {
      console.error("❌ Logout Failed:", error);
    });
};

// ✅ Generate Unique Complaint ID
function generateComplaintID() {
  return `comp_${Date.now().toString().slice(-5)}`;
}

// ✅ Initialize Complaint Form
function initializeComplaintForm() {
  const complaintForm = document.getElementById("complaintForm");

  if (!complaintForm) {
    console.warn("⚠️ No complaint form found on this page.");
    return;
  }

  complaintForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const mobileNumber = document.getElementById("mobile_number").value;
    const email = document.getElementById("email").value;
    const communicationAddress = document.getElementById("communication_address").value;
    const localityName = document.getElementById("locality_name").value;
    const wardNumber = document.getElementById("ward_number").value;
    const zoneNumber = document.getElementById("zone_number").value;
    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value;

    if (!name || !mobileNumber || !email || !communicationAddress || !localityName || !wardNumber || !zoneNumber || !category || !description) {
      alert("❌ Please fill all the fields.");
      return;
    }

    const complaintID = generateComplaintID();

    try {
      await addDoc(collection(db, "complaints"), {
        complaint_id: complaintID,
        name,
        mobileNumber,
        email,
        communicationAddress,
        localityName,
        wardNumber,
        zoneNumber,
        category,
        description,
        timestamp: new Date(),
      });

      const userRef = doc(db, "users", auth.currentUser.uid);
      await updateDoc(userRef, {
        complaints: arrayUnion(complaintID),
      });

      alert(`✅ Complaint submitted successfully! Your Complaint ID: ${complaintID}`);
      complaintForm.reset();
    } catch (error) {
      console.error("❌ Error submitting complaint:", error);
      alert("❌ Error submitting complaint. Try again later.");
    }
  });
}

// ✅ Handle Sidebar Link Clicks
document.addEventListener("DOMContentLoaded", () => {
  loadContent("index.html");
  const sidebarLinks = document.querySelectorAll(".links a");
  sidebarLinks.forEach((link) => {
    link.addEventListener("click", handleSidebarLinkClick);
  });

  if (window.location.pathname.includes("report.html")) {
    initializeComplaintForm();
  }
});
